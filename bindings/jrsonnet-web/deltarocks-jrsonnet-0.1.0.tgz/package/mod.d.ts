import { ArrValue, type ImportResolver, ObjValue, State, Val, ValKind } from "./lib/jsonnet_web.d.ts";
export interface JrsonnetFrame {
  desc: string;
  path?: string;
  line?: number;
  column?: number;
}
export declare class JrsonnetError extends Error {
  override name: "JrsonnetError";
  frames: JrsonnetFrame[];
  constructor(message: string, frames: JrsonnetFrame[], cause?: unknown);
}
export { ArrValue, type ImportResolver, ObjValue, State, Val, ValKind };
export declare class FetchImportResolver implements ImportResolver {
  constructor(base: URL | string);
  resolveFrom(from: string | undefined, path: string): Promise<string>;
  loadFileContents(resolved: string): Promise<Uint8Array>;
}
