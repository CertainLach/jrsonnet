export interface ImportResolver {
  resolveFrom(from: string | undefined, path: string): Promise<string>;
  loadFileContents(resolved: string): Promise<Uint8Array>;
}
export declare class ArrValue {
  private constructor();
  free(): void;
  at(index: number): Val | undefined;
  readonly length: number;
}
export declare class FormatOptions {
  free(): void;
  constructor();
}
export declare class ObjValue {
  private constructor();
  free(): void;
  get(key: string): Val | undefined;
  keys(): string[];
}
export declare class State {
  free(): void;
  evaluateFile(path: string): Promise<Val>;
  evaluateFileFrom(from: string, path: string): Promise<Val>;
  evaluateSnippet(name: string, snippet: string): Val;
  constructor(resolver?: ImportResolver | null);
}
export declare class Val {
  private constructor();
  free(): void;
  manifestIni(): string;
  manifestJson(indent: number): string;
  manifestToml(indent: number): string;
  manifestYaml(indent: number, quote_keys: boolean): string;
  manifestString(): string;
  manifestToString(): string;
  manifestXmlJsonml(): string;
  manifestYamlStream(indent: number, quote_keys: boolean, c_document_end: boolean): string;
  static arr(items: Val[]): Val;
  static num(n: number): Val;
  static bool(b: boolean): Val;
  static func(params: string[], callback: (...args: Val[]) => Val): Val;
  static null(): Val;
  asArr(): ArrValue | undefined;
  asNum(): number | undefined;
  asObj(): ObjValue | undefined;
  static bigint(value: bigint): Val;
  static string(s: string): Val;
  asBool(): boolean | undefined;
  applyTla(args: Record<string, Val>): Val;
  asBigint(): bigint | undefined;
  asString(): string | undefined;
  readonly kind: ValKind;
}
export declare enum ValKind {
  Null = 0,
  Bool = 1,
  Num = 2,
  Str = 3,
  Arr = 4,
  Obj = 5,
  Func = 6,
  BigInt = 7
}
export declare function format(src: string, opts: FormatOptions): string;
