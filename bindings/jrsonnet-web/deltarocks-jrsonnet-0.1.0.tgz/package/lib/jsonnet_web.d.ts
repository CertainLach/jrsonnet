// @generated file from wasmbuild -- do not edit
// deno-lint-ignore-file
// deno-fmt-ignore-file

export interface ImportResolver {
	resolveFrom(from: string | undefined, path: string): Promise<string>;
	loadFileContents(resolved: string): Promise<Uint8Array>;
}

export class ArrValue {
	private constructor();
	free(): void;
	[Symbol.dispose](): void;
	at(index: number): Val | undefined;
	readonly length: number;
}

export class FormatOptions {
	free(): void;
	[Symbol.dispose](): void;
	constructor();
}

export class ObjValue {
	private constructor();
	free(): void;
	[Symbol.dispose](): void;
	get(key: string): Val | undefined;
	keys(): string[];
}

export class State {
	free(): void;
	[Symbol.dispose](): void;
	evaluateFile(path: string): Promise<Val>;
	evaluateFileFrom(from: string, path: string): Promise<Val>;
	evaluateSnippet(name: string, snippet: string): Val;
	constructor(resolver?: ImportResolver | null);
}

export class Val {
	private constructor();
	free(): void;
	[Symbol.dispose](): void;
	manifestIni(): string;
	manifestJson(indent: number): string;
	manifestToml(indent: number): string;
	manifestYaml(indent: number, quote_keys: boolean): string;
	manifestString(): string;
	manifestToString(): string;
	manifestXmlJsonml(): string;
	manifestYamlStream(
		indent: number,
		quote_keys: boolean,
		c_document_end: boolean,
	): string;
	static arr(items: Val[]): Val;
	static num(n: number): Val;
	static bool(b: boolean): Val;
	static func(params: string[], callback: (...args: Val[]) => Val): Val;
	static null(): Val;
	asArr(): ArrValue | undefined;
	asNum(): number | undefined;
	asObj(): ObjValue | undefined;
	static bigint(value: bigint): Val;
	static string(s: string): Val;
	asBool(): boolean | undefined;
	applyTla(args: Record<string, Val>): Val;
	asBigint(): bigint | undefined;
	asString(): string | undefined;
	readonly kind: ValKind;
}

export enum ValKind {
	Null = 0,
	Bool = 1,
	Num = 2,
	Str = 3,
	Arr = 4,
	Obj = 5,
	Func = 6,
	BigInt = 7,
}

export function format(src: string, opts: FormatOptions): string;

export function setErrorFactory(f: Function): void;
